# Margonem MP3 Repo

Po wrzuceniu na GitHub uzyskaj link Raw do MP3 i użyj w dodatku Margonem.